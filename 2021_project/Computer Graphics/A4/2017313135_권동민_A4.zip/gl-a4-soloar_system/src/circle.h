#pragma once
#ifndef __CIRCLE_H__
#define __CIRCLE_H__
#define STB_IMAGE_IMPLEMENTATION

#include "cgut.h"

struct circle_t
{
	int		id = 0;
	vec3	center = vec3(0);		// 3D position for translation
	float	radius = 1.0f;		// radius
	float	theta = 0.0f;			// rotation angle
	float	dt_theta = 0.0f;

	int		origin;
	float	from_org;
	float	global_theta = 0.0f;
	float	dt_global_theta = 0.0f;

	vec4	color;				// RGBA color in [0,1]
	mat4	model_matrix;		// modeling transformation

	// public functions
	void	update(float t, float bt, std::vector<circle_t>);
};

struct ring_t
{
	int		id = 0;
	int		tex = 0;
	vec3	center = vec3(0);
	float	radius = 10.0f;

	mat4	model_matrix;

	void	update_ring(float t, float bt, std::vector<circle_t>);
};

inline std::vector<ring_t> create_rings() {
	std::vector<ring_t> rings;
	ring_t r;

	r = { 6, 10, vec3(0, 460.0f, 0), 60.0f };
	rings.emplace_back(r);
	r = { 7, 12, vec3(0, 560.0f, 0), 65.0f};
	rings.emplace_back(r);

	return rings;
}

inline std::vector<circle_t> create_circles()
{
	std::vector<circle_t> circles;
	circle_t c;
	
	c = {0, vec3(0),40.0f, 0.0f, 0.002f, 0, 0.0f, 0.0f, 0.0f, vec4(1.0f,0.5f,0.5f,1.0f)};
	circles.emplace_back(c);
	c = {1, vec3(0, 60.0f, 0), 4.0f, 0.0f, 0.04f, 0, 60.0f, (float)rand() / 32767 * 6, 0.03f, vec4(1.0f, 0.5f, 0.5f, 1.0f)};
	circles.emplace_back(c);
	c = {2, vec3(0, 90.0f, 0), 6.0f, 0.0f, 0.03f, 0, 90.0f, (float)rand() / 32767 * 6, 0.02f, vec4(1.0f, 0.5f, 0.5f, 1.0f)};
	circles.emplace_back(c);
	c = {3, vec3(0, 130.0f, 0), 10.0f, 0.0f, 0.015f, 0, 130.0f, (float)rand() / 32767 * 6, 0.01f, vec4(1.0f, 0.5f, 0.5f, 1.0f)};
	circles.emplace_back(c);
	c = {4, vec3(0, 170.0f, 0), 9.0f, 0.0f, 0.02f, 0, 170.0f, (float)rand() / 32767 * 6, 0.012f, vec4(1.0f, 0.5f, 0.5f, 1.0f)};
	circles.emplace_back(c);
	c = {5, vec3(0, 330.0f, 0), 30.0f, 0.0f, 0.009f, 0, 330.0f, (float)rand() / 32767 * 6, 0.006f, vec4(1.0f, 0.5f, 0.5f, 1.0f)};
	circles.emplace_back(c);
	c = {6, vec3(0, 460.0f, 0), 25.0f, 0.0f, 0.012f, 0, 460.0f, (float)rand() / 32767 * 6, 0.004f, vec4(1.0f, 0.5f, 0.5f, 1.0f)};
	circles.emplace_back(c);
	c = {7, vec3(0, 600.0f, 0), 13.0f, 0.0f, 0.01f, 0, 600.0f, (float)rand() / 32767 * 6, 0.009f, vec4(1.0f, 0.5f, 0.5f, 1.0f)};
	circles.emplace_back(c);
	c = {8, vec3(0, 700.0f, 0), 12.0f, 0.0f, 0.008f, 0, 680.0f, (float)rand() / 32767 * 6, 0.003f, vec4(1.0f, 0.5f, 0.5f, 1.0f)};
	circles.emplace_back(c);
	c = {9, vec3(0, 150.0f, 0), 3.0f, 0.0f, 0.04f, 3, 20.0f, (float)rand() / 32767 * 6, 0.1f, vec4(1.0f, 0.5f, 0.5f, 1.0f) };
	circles.emplace_back(c);
	c = { 9, vec3(0, 375.0f, 0), 6.0f, 0.0f, 0.04f, 5, 45.0f, (float)rand() / 32767 * 6, 0.03f, vec4(1.0f, 0.5f, 0.5f, 1.0f) };
	circles.emplace_back(c);
	c = { 9, vec3(0, 385.0f, 0), 3.0f, 0.0f, 0.02f, 5, 55.0f, (float)rand() / 32767 * 6, 0.08f, vec4(1.0f, 0.5f, 0.5f, 1.0f) };
	circles.emplace_back(c);
	c = { 9, vec3(0, 380.0f, 0), 5.0f, 0.0f, 0.03f, 5, 50.0f, (float)rand() / 32767 * 6, 0.05f, vec4(1.0f, 0.5f, 0.5f, 1.0f) };
	circles.emplace_back(c);
	c = { 9, vec3(0, 395.0f, 0), 5.0f, 0.0f, 0.035f, 5, 65.0f, (float)rand() / 32767 * 6, 0.02f, vec4(1.0f, 0.5f, 0.5f, 1.0f) };
	circles.emplace_back(c);
	c = { 9, vec3(0, 640.0f, 0), 6.0f, 0.0f, 0.03f, 7, 40.0f, (float)rand() / 32767 * 6, 0.05f, vec4(1.0f, 0.5f, 0.5f, 1.0f) };
	circles.emplace_back(c);
	c = { 9, vec3(0, 630.0f, 0), 5.0f, 0.0f, 0.02f, 7, 30.0f, (float)rand() / 32767 * 6, 0.02f, vec4(1.0f, 0.5f, 0.5f, 1.0f) };
	circles.emplace_back(c);
	c = { 9, vec3(0, 625.0f, 0), 3.0f, 0.0f, 0.04f, 7, 25.0f, (float)rand() / 32767 * 6, 0.07f, vec4(1.0f, 0.5f, 0.5f, 1.0f) };
	circles.emplace_back(c);
	c = { 9, vec3(0, 655.0f, 0), 7.0f, 0.0f, 0.04f, 7, 55.0f, (float)rand() / 32767 * 6, 0.04f, vec4(1.0f, 0.5f, 0.5f, 1.0f) };
	circles.emplace_back(c);
	c = { 9, vec3(0, 670.0f, 0), 3.0f, 0.0f, 0.03f, 7, 70.0f, (float)rand() / 32767 * 6, 0.06f, vec4(1.0f, 0.5f, 0.5f, 1.0f) };
	circles.emplace_back(c);

	return circles;
}

inline void ring_t::update_ring(float t, float bt, std::vector<circle_t> circles) {
	radius = this->radius;
	float time_scale = (t - bt) / 17 * 1000000;

	center.x = circles[id].center.x;
	center.y = circles[id].center.y;

	mat4 scale_matrix =
	{
		radius, 0, 0, 0,
		0, radius, 0, 0,
		0, 0, radius, 0,
		0, 0, 0, 1
	};

	mat4 translate_matrix =
	{
		1, 0, 0, center.x,
		0, 1, 0, center.y,
		0, 0, 1, 0,
		0, 0, 0, 1
	};

	model_matrix = translate_matrix * scale_matrix;
}

inline void circle_t::update(float t, float bt, std::vector<circle_t> circles)
{
	radius = this->radius;	// simple animation
	float time_scale = (t - bt) / 17 * 1000000;

	theta += dt_theta * time_scale;
	global_theta += dt_global_theta * time_scale;
	float c	= cos(theta), s=sin(theta);

	center.x = circles[origin].center.x + from_org * -sin(global_theta);
	center.y = circles[origin].center.y + from_org * cos(global_theta);

	// these transformations will be explained in later transformation lecture
	mat4 scale_matrix =
	{
		radius, 0, 0, 0,
		0, radius, 0, 0,
		0, 0, radius, 0,
		0, 0, 0, 1
	};

	mat4 rotation_matrix =
	{
		c,-s, 0, 0,
		s, c, 0, 0,
		0, 0, 1, 0,
		0, 0, 0, 1
	};

	mat4 translate_matrix =
	{
		1, 0, 0, center.x,
		0, 1, 0, center.y,
		0, 0, 1, 0,
		0, 0, 0, 1
	};
	
	model_matrix = translate_matrix*rotation_matrix*scale_matrix;
	//model_matrix = projection_matrix * translate_matrix * scale_matrix;
}

#endif
